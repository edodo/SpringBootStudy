package com.base.myspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyspringbootGradleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
